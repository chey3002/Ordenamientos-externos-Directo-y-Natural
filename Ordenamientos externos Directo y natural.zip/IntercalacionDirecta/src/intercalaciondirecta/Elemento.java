/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intercalaciondirecta;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author carlo
 */
public class Elemento {
    public int numero;

    public int getNumero() {
        return numero;
    }

    public String getTexto() {
        return Texto;
    }

    public boolean isBoleano() {
        return boleano;
    }
    public String getFecha() {
        return fecha;
    }
    public String Texto;
    public boolean boleano;
    
    public String fecha;

    public Elemento(int numero, String Texto, boolean boleano, String fecha) {
        this.numero = numero;
        this.Texto = Texto;
        this.boleano = boleano;
        this.fecha=fecha;
    }

    public Elemento() {
    }
    public String toString() {
        return this.numero+";"+this.Texto+";"+this.boleano+";"+this.fecha;
    }
}

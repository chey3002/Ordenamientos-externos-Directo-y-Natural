/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intercalaciondirecta;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Scanner;
/**
 *
 * @author carlo
 */
public class IntercalacionDirecta {

    /**
     * @param args the command line arguments
     */
    
public static ArrayList<Elemento> burbujadate(ArrayList<Elemento> lista,int maximo) throws ParseException{
        int i,j;
        for(i=maximo-2;i>=0;i--){
            for(j=0;j<=i;j++)
                {
                   SimpleDateFormat formato=new SimpleDateFormat("dd/MM/yyyy");
                   Date date1=formato.parse(lista.get(j).getFecha());
                   Date date2=formato.parse(lista.get(j+1).getFecha());
                   if(date2.before(date1))
                   {
                       
                        Elemento t;
                        t=lista.get(j);
                        lista.set(j,lista.get(j+1));
                        lista.set(j+1, t);
                        
                   }
                }
            }
 return lista;
}
public static ArrayList<Elemento> burbujanum(ArrayList<Elemento> lista,int maximo){
        int i,j;
        for(i=maximo-2;i>=0;i--){
            for(j=0;j<=i;j++)
                {
                   
                   if(lista.get(j).getNumero()>lista.get(j+1).getNumero())
                   {
                       
                        Elemento t;
                        t=lista.get(j);
                        lista.set(j,lista.get(j+1));
                        lista.set(j+1, t);
                        
                   }
                }
            }
 return lista;
}
public static ArrayList<Elemento> burbujabol(ArrayList<Elemento> lista,int maximo){
        int i,j;
        for(i=maximo-2;i>=0;i--){
            for(j=0;j<=i;j++)
                {
                   
                   if(lista.get(j+1).isBoleano())
                   {
                       
                        Elemento t;
                        t=lista.get(j);
                        lista.set(j,lista.get(j+1));
                        lista.set(j+1, t);
                        
                   }
                }
            }
 return lista;
}
public static ArrayList<Elemento> burbujatxt(ArrayList<Elemento> lista,int maximo){
        int i,j;
        for(i=maximo-2;i>=0;i--){
            for(j=0;j<=i;j++)
                {
                   
                   if(lista.get(j).getTexto().compareTo(lista.get(j+1).getTexto())>0)
                   {
                       
                        Elemento t;
                        t=lista.get(j);
                        lista.set(j,lista.get(j+1));
                        lista.set(j+1, t);
                        
                   }
                }
            }
 return lista;
}
    public static void main(String[] args) throws IOException, ParseException {
        File file=new File("1.csv");
        File grupo1=new File("temp1.csv");
        File grupo2=new File("temp2.csv");
        grupo1.createNewFile();
        grupo2.createNewFile();
        SimpleDateFormat formato=new SimpleDateFormat("dd/MM/YYYY");
        if(!file.exists()){
            try{
                file.createNewFile();
            }catch(IOException ex){
                ex.printStackTrace();
            }
        }
        
        do{
            int pasadas=0;
        int i;
         System.out.println ("Elija el campo de ordenamiento:");
         System.out.println ("1)Campo1(Numeros)");
         System.out.println ("2)Campo2(Texto)");
         System.out.println ("3)Campo3(Boleano)");
         System.out.println ("4)Campo4(Fecha)");
         System.out.println ("");
         int opcion = 1;
        Scanner entradaEscaner = new Scanner (System.in); //Creación de un objeto Scanner
        opcion = Integer.decode(entradaEscaner.nextLine ());
        do{
           
           pasadas++;
           
        BufferedWriter bw = new BufferedWriter(new FileWriter(grupo1));
        bw.write("");
        bw.close();
        bw = new BufferedWriter(new FileWriter(grupo2));
        bw.write("");
        bw.close();
         
        Scanner inputStream=new Scanner(file);
        i=0;
        FileWriter g1=new FileWriter(grupo1,true);
        FileWriter g2=new FileWriter(grupo2,true);
        boolean bol1=true;
        boolean bol2=false;
        while(inputStream.hasNext()){
            
            
            if(bol1){
                for(int k=0;k<pasadas;k++){
                    try{
                        String data=inputStream.next();
                    g1.append(data+"\n");
                    i++;
                    }catch(NoSuchElementException ex){
                        
                    }
                    
                }
            }
            if(bol2){
                for(int k=0;k<pasadas;k++){
                    try{
                        String data=inputStream.next();
                    g2.append(data+"\n");
                    i++;
                    }catch(NoSuchElementException ex){
                        
                    }
                }
                bol1=true;
                bol2=false;
            }else{
                bol2=true;
                bol1=false;
            }
        }
        
        g2.close();
        g1.close();
        int j;
        bw = new BufferedWriter(new FileWriter(file));
        bw.write("");
        bw.close();
        BufferedWriter fw = new BufferedWriter(new FileWriter(file));
        Scanner inputStream1=new Scanner(grupo1);
        Scanner inputStream2=new Scanner(grupo2);
        int val1 = 0;
        int val2 = 0;
        String[] linea1=null;
        String[] linea2=null;
        String data1 = null;
        String data2 = null;
        String texto1 = null;
        String texto2 = null;
        String fecha1=null;
        ArrayList<Elemento> lista1 = new ArrayList();
        ArrayList<Elemento> lista2 = new ArrayList();
        ArrayList<Elemento> listaf = new ArrayList();
        boolean boleano1 = false;
        boolean boleano2;
        int rec;
        if(i%2==0)
            rec=i/(2*pasadas);
        else
            rec=(i/(2*pasadas))+1;
       do{
               data1="0; ; ; ";
                    
                    lista1.clear();
                    if(inputStream1.hasNext()){
                    for(int k=0;k<Math.pow(2, (pasadas-1));k++){
                    if(inputStream1.hasNext()){
                        data1=inputStream1.next();
                        linea1=data1.split(";");
                        int int1=Integer.parseInt(linea1[0]);
                        texto1=linea1[1];
                        if(linea1[2].matches("true")){
                        boleano1=true;
                    }else{
                        boleano1=false;
                    }

                    fecha1=linea1[3];
          
                     lista1.add(new Elemento(int1,texto1,boleano1,fecha1));
                            }
                    }
                    }
                    
                    lista2.clear();
                    if(inputStream2.hasNext()){
                        for(int k=0;k<Math.pow(2, (pasadas-1));k++){
                       if(inputStream2.hasNext()){

                        data2=inputStream2.next();

                        linea2=data2.split(";");
                    int int1=Integer.parseInt(linea2[0]);
                        texto1=linea2[1];
                  
                  
                        if(linea2[2].matches("true")){
                        boleano1=true;
                    }else{
                        boleano1=false;
                    }
                        fecha1=linea2[3];  
                    lista2.add(new Elemento(int1,texto1,boleano1,fecha1));
                       }
                    }
                    }
                    listaf.clear();
                    listaf.addAll(lista1);
                    listaf.addAll(lista2);
                    switch (opcion){
                        case 1:
                            burbujanum(listaf,listaf.size());
                        break;
                        case 2:
                            burbujatxt(listaf,listaf.size());
                        break;
                        case 3:
                            burbujabol(listaf,listaf.size());
                        break;
                        case 4:
                            burbujadate(listaf,listaf.size());
                        break;
                        default:  burbujanum(listaf,listaf.size());
                     break;
                        
                    }
                   
                    for(int k=0;k<listaf.size();k++){
                       
                            fw.append(listaf.get(k).toString()+"\n");
                        
                        
                    }
        }while(inputStream1.hasNext()||inputStream2.hasNext());
        
       fw.close();
       
      
        }while(Math.pow(2, (pasadas-1))<=((i+1)/2));
        
        }while(true);
    }
    
}

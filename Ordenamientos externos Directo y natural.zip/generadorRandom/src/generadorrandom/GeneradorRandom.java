/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package generadorrandom;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.Random;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 *
 * @author Usuario
 */
public class GeneradorRandom {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        File rand=new File("1.csv");
       if(!rand.exists()){
            try{
                rand.createNewFile();
            }catch(IOException ex){
                ex.printStackTrace();
            }
        }
  BufferedWriter bw = new BufferedWriter(new FileWriter(rand));
  bw.append("");
  bw.close();
  int i=0;
       do{
        bw = new BufferedWriter(new FileWriter(rand,true));
           Random  entero = new Random();
       String parte1=""+(int)(entero.nextDouble() * 100000);
       
       Random  boleano = new Random();
       int parte2=(int)(boleano.nextDouble() * 2+1);
      
       Random  txt = new Random();
       SecureRandom random = new SecureRandom();
       String texto=Long.toHexString(Double.doubleToLongBits(Math.random()));
      
        Calendar unaFecha;
        int numero = 0;
        Random aleatorio=new Random();
       unaFecha = Calendar.getInstance();
        unaFecha.set (aleatorio.nextInt(10)+2014, aleatorio.nextInt(12)+1, aleatorio.nextInt(30)+1);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        
        bw.append(parte1);
        bw.append(";"+texto);
        if(parte2==1){
            bw.append(";true");
        }else{
            bw.append(";false");
        }
        bw.append(";"+sdf.format(unaFecha.getTime())+"\n");
        bw.close();
        i++;
       }while(i<5000);
       System.out.println("Archivo creado");
      
    }
    
}

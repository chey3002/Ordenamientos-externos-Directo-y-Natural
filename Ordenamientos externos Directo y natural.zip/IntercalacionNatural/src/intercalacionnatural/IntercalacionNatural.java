/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intercalacionnatural;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Scanner;
public class IntercalacionNatural {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, ParseException {
        File file=new File("1.csv");
        System.out.println(file.length());
        File grupo1=new File("temp1.csv");
        File grupo2=new File("temp2.csv");
        File fileaux=new File("auxiliar.csv");
        fileaux.createNewFile();
        grupo1.createNewFile();
        grupo2.createNewFile();
        SimpleDateFormat formato=new SimpleDateFormat("dd/MM/yyyy");
        
        BufferedWriter bw = new BufferedWriter(new FileWriter(grupo1));
        bw.write("");
        bw.close();
        bw = new BufferedWriter(new FileWriter(grupo2));
        bw.write("");
        bw.close();
       do{
           
            System.out.println ("Elija el campo de ordenamiento:");
         System.out.println ("1)Campo1(Numeros)");
         System.out.println ("2)Campo2(Texto)");
         System.out.println ("3)Campo3(Boleano)");
         System.out.println ("4)Campo4(Fecha)");
         System.out.println ("");
         int opcion = 1;
        Scanner entradaEscaner = new Scanner (System.in); //Creación de un objeto Scanner
        opcion = Integer.decode(entradaEscaner.nextLine ());
        
        switch (opcion){
            case 1:
                do{
          
        BufferedWriter g1 = new BufferedWriter(new FileWriter(grupo1));
        BufferedWriter g2= new BufferedWriter(new FileWriter(grupo2));
        String[] linea1 = null;
        String[] linea2 = null;
        

          BufferedWriter afw = new BufferedWriter(new FileWriter(fileaux));
          Scanner inputStream=new Scanner(file);
        g1 = new BufferedWriter(new FileWriter(grupo1));
        g2 = new BufferedWriter(new FileWriter(grupo2));
        String ant=inputStream.next();
        g1.append(ant+"\n");
        ArrayList <Integer> piv1=new ArrayList();
        ArrayList <Integer> piv2=new ArrayList();
        
        boolean bol1=true;
        boolean bol2=true;
        int i=0;
        int j=0;
                    while(inputStream.hasNext()){
                        boolean visited=false;
                        String act=inputStream.next();
                        linea1=ant.split(";");
                        linea2=act.split(";");
                        if(!visited){
                            if(bol1&&!bol2){
                               
                            if(Integer.parseInt(linea1[0])<=Integer.parseInt(linea2[0])){
                                i++;
                                g1.append(act+"\n");
                                bol1=true;
                                bol2=false;
                                visited=true;
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv1.add(i);
                                
                               
                                
                                visited=true;
                            }
                        }
                        }
                        if(!visited){
                            if(!bol1&&bol2){
                            if(Integer.parseInt(linea1[0])<=Integer.parseInt(linea2[0])){
                                g2.append(act+"\n");
                                bol1=false;
                                j++;
                                bol2=true;
                                visited=true;
                            }else{
                                g1.append(act+"\n");
                                bol2=false;
                                bol1=true;
                                i++;
                                piv2.add(j);
                                
                                visited=true;
                            }
                        }
                        }
                        
                        if(!visited){
                            if(bol1&&bol2){
                            if(Integer.parseInt(linea1[0])<=Integer.parseInt(linea2[0])){
                                g1.append(act+"\n");
                                bol1=true;
                                i++;
                                bol2=false;
                                visited=true;
                                
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv1.add(i);
                               
                                visited=true;
                            }
                        }
                        }
                        
                        ant=act;
                    }
                   
                  
                    g2.close();
                    g1.close();
                   
                 
                    Scanner arc1=new Scanner(grupo1);
                    Scanner arc2=new Scanner(grupo2);
                    bol1=true;
                    bol2=true;
                    String arch2 = null;
                    String arch1 = null;
                    i=0;
                    j=0;
                    if(arc2.hasNext()){
                    arch1=arc1.next();    
                    arch2=arc2.next();
                    int p1=0;
                    int p20;
                    i=1;
                    j=1;
                    int p=0;
                    do{
                        
                        
                        linea1=arch1.split(";");
                        linea2=arch2.split(";");
                        if(Integer.decode(linea1[0])<=Integer.decode(linea2[0])){
                            afw.append(arch1+"\n");
                            arch1=arc1.next();
                            i++;
                            if(!arc1.hasNext()){
                                linea1=arch1.split(";");
                                linea2=arch2.split(";");
                                if(Integer.decode(linea1[0])<=Integer.decode(linea2[0])){
                                    afw.append(arch1+"\n");
                                    afw.append(arch2+"\n");
                                }else{
                                    afw.append(arch2+"\n");
                                    afw.append(arch1+"\n");
                                }
                            }
                                
                        }else{
                            afw.append(arch2+"\n");
                            arch2=arc2.next();
                            j++;
                            if(!arc2.hasNext()){
                                linea1=arch1.split(";");
                                linea2=arch2.split(";");
                                if(Integer.decode(linea1[0])<=Integer.decode(linea2[0])){
                                    afw.append(arch1+"\n");
                                    afw.append(arch2+"\n");
                                }else{
                                    afw.append(arch2+"\n");
                                    afw.append(arch1+"\n");
                                }
                            }
                                    
                        }
                            
                        if(i<=piv1.get(piv1.size()-1)){
                            if(p<piv1.size()){
                                if(i>piv1.get(p)){
                            if(piv2.size()!=0){
                                if(p<piv2.size()){
                                    while(j<=piv2.get(p)){
                                afw.append(arch2+"\n");
                                if(arc2.hasNext()){
                                    arch2=arc2.next();
                                }else{
                                    afw.append(arch1+"\n");
                                }
                                j++;
                            }
                                }
                            }
                            p++;
                        }
                            
                            }
                        }
                        if(piv2.size()!=0){
                            if(p<piv2.size()){
                                if(j<=piv2.get(piv2.size()-1)){
                            if(j>piv2.get(p)){
                            while(i<=piv1.get(p)){
                                afw.append(arch1+"\n");
                                if(arc1.hasNext()){
                                    arch1=arc1.next();
                                }else{
                                    afw.append(arch2+"\n");
                                }
                                i++;
                            }
                            p++;
                        }
                        }
                            
                            }
                        }
                    }while(arc2.hasNext()&&arc1.hasNext() );
                    
                    while(arc2.hasNext()){
                            arch2=arc2.next();
                            afw.append(arch2+"\n");
                        }
                    while(arc1.hasNext()){
                            arch1=arc1.next();
                            afw.append(arch1+"\n");
                        }
                    }else{
                        while(arc1.hasNext()){
                            arch1=arc1.next();
                             afw.append(arch1+"\n");
                        }
                           
                        
                    }
                        
             
                afw.close(); 
        Scanner ns=new Scanner(fileaux);
        
        BufferedWriter fwaux = new BufferedWriter(new FileWriter(file));
        while(ns.hasNext()){
            fwaux.append(ns.next()+"\n");
        }
        fwaux.close();
            }while(grupo2.length()!=0);
       
                break;
            case 2:
                do{
           
          
        BufferedWriter g1 = new BufferedWriter(new FileWriter(grupo1));
        BufferedWriter g2= new BufferedWriter(new FileWriter(grupo2));
        String[] linea1 = null;
        String[] linea2 = null;
        

          BufferedWriter afw = new BufferedWriter(new FileWriter(fileaux));
          Scanner inputStream=new Scanner(file);
        g1 = new BufferedWriter(new FileWriter(grupo1));
        g2 = new BufferedWriter(new FileWriter(grupo2));
        String ant=inputStream.next();
        g1.append(ant+"\n");
        ArrayList <Integer> piv1=new ArrayList();
        ArrayList <Integer> piv2=new ArrayList();
        
        boolean bol1=true;
        boolean bol2=true;
        int i=0;
        int j=0;
                    while(inputStream.hasNext()){
                        
                        boolean visited=false;
                        String act=inputStream.next();
                        linea1=ant.split(";");
                        linea2=act.split(";");
                        if(!visited){
                            if(bol1&&!bol2){
                               
                            if(linea1[1].compareTo(linea2[1])<=0){
                                i++;
                                g1.append(act+"\n");
                                bol1=true;
                                bol2=false;
                                visited=true;
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv1.add(i);
                                
                                visited=true;
                            }
                        }
                        }
                        if(!visited){
                            if(!bol1&&bol2){
                            if(linea1[1].compareTo(linea2[1])<=0){
                                g2.append(act+"\n");
                                bol1=false;
                                j++;
                                bol2=true;
                                visited=true;
                            }else{
                                g1.append(act+"\n");
                                bol2=false;
                                bol1=true;
                                i++;
                                piv2.add(j);
                                
                                visited=true;
                            }
                        }
                        }
                        
                        if(!visited){
                            if(bol1&&bol2){
                            if(linea1[1].compareTo(linea2[1])<=0){
                                g1.append(act+"\n");
                                bol1=true;
                                i++;
                                bol2=false;
                                visited=true;
                                
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv2.add(j);
                                piv1.add(i);
                                
                                visited=true;
                            }
                        }
                        }
                        
                        ant=act;
                    }
                   
                          
                    g2.close();
                    g1.close();
                   
                 
                    
                    Scanner arc1=new Scanner(grupo1);
                    Scanner arc2=new Scanner(grupo2);
                    bol1=true;
                    bol2=true;
                    String arch2 = null;
                    String arch1 = null;
                    i=0;
                    j=0;
                    if(arc2.hasNext()){
                    arch1=arc1.next();    
                    arch2=arc2.next();
                    int p1=0;
                    int p20;
                    i=1;
                    j=1;
                    int p=0;
                    do{
                        
                        
                        linea1=arch1.split(";");
                        linea2=arch2.split(";");
                        if(linea1[1].compareTo(linea2[1])<=0){
                            afw.append(arch1+"\n");
                            arch1=arc1.next();
                            i++;
                            if(!arc1.hasNext()){
                                linea1=arch1.split(";");
                                linea2=arch2.split(";");
                                if(linea1[1].compareTo(linea2[1])<=0){
                                    afw.append(arch1+"\n");
                                    afw.append(arch2+"\n");
                                }else{
                                    afw.append(arch2+"\n");
                                    afw.append(arch1+"\n");
                                }
                            }
                                
                        }else{
                            afw.append(arch2+"\n");
                            arch2=arc2.next();
                            j++;
                            if(!arc2.hasNext()){
                               linea1=arch1.split(";");
                                linea2=arch2.split(";");
                                if(linea1[1].compareTo(linea2[1])<=0){
                                    afw.append(arch1+"\n");
                                    afw.append(arch2+"\n");
                                }else{
                                    afw.append(arch2+"\n");
                                    afw.append(arch1+"\n");
                                }
                            }
                                    
                        }
                            
                        if(i<=piv1.get(piv1.size()-1)){
                            if(p<piv1.size()){
                                if(i>piv1.get(p)){
                            if(piv2.size()!=0){
                                while(j<=piv2.get(p)){
                                afw.append(arch2+"\n");
                                if(arc2.hasNext()){
                                    arch2=arc2.next();
                                }else{
                                    afw.append(arch1+"\n");
                                }
                                j++;
                            }
                                
                            }
                            p++;
                        }
                            
                            }
                        }
                        if(piv2.size()!=0){
                            if(p<piv2.size()){
                                if(j<=piv2.get(piv2.size()-1)){
                            if(j>piv2.get(p)){
                            while(i<=piv1.get(p)){
                                afw.append(arch1+"\n");
                                if(arc1.hasNext()){
                                    arch1=arc1.next();
                                }else{
                                    afw.append(arch2+"\n");
                                }
                                i++;
                            }
                            p++;
                        }
                        }
                            
                            }
                        }
                    }while(arc2.hasNext()&&arc1.hasNext() );
                    while(arc1.hasNext()){
                            arch1=arc1.next();
                            afw.append(arch1+"\n");
                        }
                    while(arc2.hasNext()){
                            arch2=arc2.next();
                            afw.append(arch2+"\n");
                        }
                    }else{
                        while(arc1.hasNext()){
                            arch1=arc1.next();
                             afw.append(arch1+"\n");
                        }
                           
                        
                    }
                        
            
                afw.close(); 
        Scanner ns=new Scanner(fileaux);
        
        BufferedWriter fwaux = new BufferedWriter(new FileWriter(file));
        while(ns.hasNext()){
            fwaux.append(ns.next()+"\n");
        }
        fwaux.close();
            }while(grupo2.length()!=0);
     
                break;
                case 3:
        {
            
            
              
                
                BufferedWriter g1 = new BufferedWriter(new FileWriter(grupo1));
                BufferedWriter g2= new BufferedWriter(new FileWriter(grupo2));
                String[] linea1 = null;
                String[] linea2 = null;
                
                
                BufferedWriter afw = new BufferedWriter(new FileWriter(fileaux));
                Scanner inputStream=new Scanner(file);
                g1 = new BufferedWriter(new FileWriter(grupo1));
                g2 = new BufferedWriter(new FileWriter(grupo2));
                String ant=inputStream.next();
                g1.append(ant+"\n");
                ArrayList <Integer> piv1=new ArrayList();
                ArrayList <Integer> piv2=new ArrayList();
                
                boolean bol1=true;
                boolean bol2=true;
                int i=0;
                int j=0;
                while(inputStream.hasNext()){
                    
                    boolean visited=false;
                    String act=inputStream.next();
                    linea1=ant.split(";");
                    linea2=act.split(";");
                    if(!visited){
                        if(bol1&&!bol2){
                            
                            if(linea1[2].contains("true")){
                                i++;
                                g1.append(act+"\n");
                                bol1=true;
                                bol2=false;
                                visited=true;
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv1.add(i);
                                
                                visited=true;
                            }
                        }
                    }
                    if(!visited){
                        if(!bol1&&bol2){
                            if(linea1[2].contains("true")){
                                g2.append(act+"\n");
                                bol1=false;
                                j++;
                                bol2=true;
                                visited=true;
                            }else{
                                g1.append(act+"\n");
                                bol2=false;
                                bol1=true;
                                i++;
                                piv2.add(j);
                                
                                visited=true;
                            }
                        }
                    }
                    
                    if(!visited){
                        if(bol1&&bol2){
                            if(linea1[2].contains("true")){
                                g1.append(act+"\n");
                                bol1=true;
                                i++;
                                bol2=false;
                                visited=true;
                                
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv2.add(j);
                                piv1.add(i);
                               
                                visited=true;
                            }
                        }
                    }
                    
                    ant=act;
                }
                
                
                g2.close();
                g1.close();
                
             
                
                Scanner arc1=new Scanner(grupo1);    
                Scanner arc2=new Scanner(grupo2);
                bol1=true;
                bol2=true;
                String arch2 = null;
                String arch1 = null;
                i=0;
                j=0;
                if(arc2.hasNext()){                 
                    int p1=0;
                    int p20;
                    i=1;
                    j=1;
                    int p=0;
                    while(arc1.hasNext()){
                         arch1=arc1.next();
                        linea1=arch1.split(";");
                        
                        if(linea1[2].compareTo("true")==0)
                            afw.append(arch1+"\n");
                        
                    }
                
                while(arc2.hasNext()){
                         arch2=arc2.next();
                        linea2=arch2.split(";");
                    
                        if(linea2[2].compareTo("true")==0)
                            afw.append(arch2+"\n");
                        
                    }
                arc1=new Scanner(grupo1);    
                arc2=new Scanner(grupo2);
                while(arc1.hasNext()){
                         arch1=arc1.next();
                        linea1=arch1.split(";");
                        if(linea1[2].compareTo("false")==0)
                            afw.append(arch1+"\n");
                        
                    }
                
                while(arc2.hasNext()){
                         arch2=arc2.next();
                        linea2=arch2.split(";");
                    
                        if(linea2[2].compareTo("false")==0)
                            afw.append(arch2+"\n");
                        
                    }
                }else{                        
                    while(arc1.hasNext()){
                        arch1=arc1.next();
                        afw.append(arch1+"\n");
                    }
                    
                    
                }
                
              
                afw.close();
                Scanner ns=new Scanner(fileaux);
               
                BufferedWriter fwaux = new BufferedWriter(new FileWriter(file));
                while(ns.hasNext()){
                    fwaux.append(ns.next()+"\n");
                }
                fwaux.close();
                
        }
    
                break;
                case 4:
                do{
            
          
        BufferedWriter g1 = new BufferedWriter(new FileWriter(grupo1));
        BufferedWriter g2= new BufferedWriter(new FileWriter(grupo2));
        String[] linea1 = null;
        String[] linea2 = null;
        

          BufferedWriter afw = new BufferedWriter(new FileWriter(fileaux));
          Scanner inputStream=new Scanner(file);
        g1 = new BufferedWriter(new FileWriter(grupo1));
        g2 = new BufferedWriter(new FileWriter(grupo2));
        String ant=inputStream.next();
        g1.append(ant+"\n");
        ArrayList <Integer> piv1=new ArrayList();
        ArrayList <Integer> piv2=new ArrayList();
        
        boolean bol1=true;
        boolean bol2=true;
        int i=0;
        int j=0;
                    while(inputStream.hasNext()){
                        
                        boolean visited=false;
                        String act=inputStream.next();
                        linea1=ant.split(";");
                        linea2=act.split(";");
                        if(!visited){
                            if(bol1&&!bol2){
                              Date date1=formato.parse(linea1[3]);
                              Date date2=formato.parse(linea2[3]);
                              
                            if(date2.after(date1)||date2.compareTo(date1)==0){
                                i++;
                                g1.append(act+"\n");
                                bol1=true;
                                bol2=false;
                                visited=true;
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv1.add(i);
                                
                                visited=true;
                            }
                        }
                        }
                        if(!visited){
                            if(!bol1&&bol2){
                                
                            Date date1=formato.parse(linea1[3]);
                              Date date2=formato.parse(linea2[3]);
                            if(date2.after(date1)||date2.compareTo(date1)==0){
                                g2.append(act+"\n");
                                bol1=false;
                                j++;
                                bol2=true;
                                visited=true;
                            }else{
                                g1.append(act+"\n");
                                bol2=false;
                                bol1=true;
                                i++;
                                piv2.add(j);
                                
                                visited=true;
                            }
                        }
                        }
                        
                        if(!visited){
                            if(bol1&&bol2){
                           Date date1=formato.parse(linea1[3]);
                              Date date2=formato.parse(linea2[3]);
                            if(date2.after(date1)||date2.compareTo(date1)==0){
                                g1.append(act+"\n");
                                bol1=true;
                                i++;
                                bol2=false;
                                visited=true;
                                
                            }else{
                                g2.append(act+"\n");
                                bol2=true;
                                bol1=false;
                                j++;
                                piv2.add(j);
                                piv1.add(i);
                                visited=true;
                            }
                        }
                        }
                        
                        ant=act;
                    }
                   
                          
                    g2.close();
                    g1.close();
                   
                    
                    Scanner arc1=new Scanner(grupo1);
                    Scanner arc2=new Scanner(grupo2);
                    bol1=true;
                    bol2=true;
                    String arch2 = null;
                    String arch1 = null;
                    i=0;
                    j=0;
                    if(arc2.hasNext()){
                    arch1=arc1.next();    
                    arch2=arc2.next();
                    int p1=0;
                    int p20;
                    i=1;
                    j=1;
                    int p=0;
                    do{
                        
                        
                        linea1=arch1.split(";");
                        linea2=arch2.split(";");
                                Date date1=formato.parse(linea1[3]);
                              Date date2=formato.parse(linea2[3]);
                            if(date2.after(date1)||date2.compareTo(date1)==0){
                            afw.append(arch1+"\n");
                            arch1=arc1.next();
                            i++;
                            if(!arc1.hasNext()){
                              linea1=arch1.split(";");
                               linea2=arch2.split(";");
                               date1=formato.parse(linea1[3]);
                              date2=formato.parse(linea2[3]);
                                if(date2.after(date1)||date2.compareTo(date1)==0){
                                    afw.append(arch1+"\n");
                                    afw.append(arch2+"\n");
                                }else{
                                    afw.append(arch2+"\n");
                                    afw.append(arch1+"\n");
                                }
                            }
                                
                        }else{
                            afw.append(arch2+"\n");
                            arch2=arc2.next();
                            j++;
                            if(!arc2.hasNext()){
                                linea1=arch1.split(";");
                               linea2=arch2.split(";");
                               date1=formato.parse(linea1[3]);
                              date2=formato.parse(linea2[3]);
                                if(date2.after(date1)||date2.compareTo(date1)==0){
                                    afw.append(arch1+"\n");
                                    afw.append(arch2+"\n");
                                }else{
                                    afw.append(arch2+"\n");
                                    afw.append(arch1+"\n");
                                }
                            }
                                    
                        }
                            
                        if(i<=piv1.get(piv1.size()-1)){
                            if(p<piv1.size()){
                                if(i>piv1.get(p)){
                            if(piv2.size()!=0){
                                while(j<=piv2.get(p)){
                                afw.append(arch2+"\n");
                                if(arc2.hasNext()){
                                    arch2=arc2.next();
                                }else{
                                    afw.append(arch1+"\n");
                                }
                                j++;
                            }
                            }
                            p++;
                        }
                            
                            }
                        }
                        if(piv2.size()!=0){
                            if(p<piv2.size()){
                                if(j<=piv2.get(piv2.size()-1)){
                            if(j>piv2.get(p)){
                            if(p<piv1.size()){
                                while(i<=piv1.get(p)){
                                afw.append(arch1+"\n");
                                if(arc1.hasNext()){
                                    arch1=arc1.next();
                                }else{
                                    afw.append(arch2+"\n");
                                }
                                i++;
                            }
                            }
                            p++;
                        }
                        }
                            
                            }
                        }
                    }while(arc2.hasNext()&&arc1.hasNext() );
                    while(arc1.hasNext()){
                            arch1=arc1.next();
                            afw.append(arch1+"\n");
                        }
                    while(arc2.hasNext()){
                            arch2=arc2.next();
                            afw.append(arch2+"\n");
                        }
                    }else{
                        while(arc1.hasNext()){
                            arch1=arc1.next();
                             afw.append(arch1+"\n");
                        }
                           
                        
                    }
                        
                
                afw.close(); 
        Scanner ns=new Scanner(fileaux);
       
        BufferedWriter fwaux = new BufferedWriter(new FileWriter(file));
        while(ns.hasNext()){
            fwaux.append(ns.next()+"\n");
        }
        fwaux.close();
            }while(grupo2.length()!=0);
                    break;
                    
                    
        }
       }while(true);
        
        
    //    }while(grupo1.length()<=file.length());
        
       
        
    }
    
}